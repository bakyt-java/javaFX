# calculator-javafx
Simple calculator written in Java as JavaFX application.
